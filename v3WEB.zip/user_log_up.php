<?php  
session_start();
// বাংলাদেশ সময় সেট করা
date_default_timezone_set('Asia/Dhaka'); 
?>
<div class="table-responsive" style="max-height: 500px;"> 
  <table class="table">
    <thead class="table-primary">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Serial Number</th>
        <th>Card UID</th>
        <th>Device Dep</th>
        <th>Date</th>
        <th>Time In</th>
        <th>Time Out</th>
        <th>Total Hours</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody class="table-secondary">
      <?php
        require 'connectDB.php';

        // ১. ফিল্টার বাটন ক্লিক করলে
        if (isset($_POST['log_date'])) {
            $searchQuery = " 1=1 "; 

            if (!empty($_POST['date_sel_start'])) {
                $start_date = $_POST['date_sel_start'];
                if (!empty($_POST['date_sel_end'])) {
                    $end_date = $_POST['date_sel_end'];
                    $searchQuery .= " AND checkindate BETWEEN '$start_date' AND '$end_date'";
                } else {
                    $searchQuery .= " AND checkindate = '$start_date'";
                }
            }

            if (isset($_POST['time_sel']) && $_POST['time_sel'] != "0") {
                $time_col = ($_POST['time_sel'] == "Time_in") ? "timein" : "timeout";
                if (!empty($_POST['time_sel_start']) && !empty($_POST['time_sel_end'])) {
                    $searchQuery .= " AND $time_col BETWEEN '".$_POST['time_sel_start']."' AND '".$_POST['time_sel_end']."'";
                }
            }

            if (!empty($_POST['card_sel']) && $_POST['card_sel'] != "0") {
                $searchQuery .= " AND card_uid = '".$_POST['card_sel']."'";
            }

            if (!empty($_POST['dev_sel']) && $_POST['dev_sel'] != "0") {
                $searchQuery .= " AND device_uid = '".$_POST['dev_sel']."'";
            }

            $_SESSION['searchQuery'] = $searchQuery;
        } 
        
        // ২. প্রথমবার পেজ লোড হলে (select_date=1) বা সেশন না থাকলে
        if (!isset($_SESSION['searchQuery']) || (isset($_POST['select_date']) && $_POST['select_date'] == 1)) {
            // ডিফল্টভাবে সব ডাটা দেখানোর জন্য "1=1" অথবা আজকের জন্য "checkindate = CURDATE()"
            $_SESSION['searchQuery'] = " 1=1 "; 
        }

        $sql = "SELECT * FROM users_logs WHERE " . $_SESSION['searchQuery'] . " ORDER BY id DESC";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <TR>
                  <TD><?php echo $row['id'];?></TD>
                  <TD><?php echo $row['username'];?></TD>
                  <TD><?php echo $row['serialnumber'];?></TD>
                  <TD><?php echo $row['card_uid'];?></TD>
                  <TD><?php echo $row['device_dep'];?></TD>
                  <TD><?php echo $row['checkindate'];?></TD>
                  <TD><?php echo (!empty($row['timein']) && $row['timein'] != "00:00:00") ? date("h:i A", strtotime($row['timein'])) : "--:--"; ?></TD>
                  <TD><?php echo (!empty($row['timeout']) && $row['timeout'] != "00:00:00") ? date("h:i A", strtotime($row['timeout'])) : "--:--"; ?></TD>
                  <TD>
                    <?php 
                    if (!empty($row['timein']) && !empty($row['timeout']) && $row['timeout'] != "00:00:00") {
                        $t1 = new DateTime($row['timein']);
                        $t2 = new DateTime($row['timeout']);
                        $interval = $t1->diff($t2);
                        echo $interval->format('%h hr %i min');
                    } else {
                        echo '<span style="color: #e67e22; font-weight: bold;">Working...</span>';
                    }
                    ?>
                  </TD>
                  <TD>
    <a href="edit_log.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">Edit</a>
</TD>
                </TR>
                <?php
            }
        } else {
            echo "<tr><td colspan='9' style='text-align:center;'>No logs found.</td></tr>";
        }
      ?>
    </tbody>
  </table>
</div>