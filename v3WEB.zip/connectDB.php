<?php
/* Database connection settings */
	$servername = "localhost";
    $username = "qarabicn_attendanceQA";		//put your phpmyadmin username.(default is "root")
    $password = "37=c.K!mqPircC)i";			//if your phpmyadmin has a password put it here.(default is "root")
    $dbname = "qarabicn_attendance_db";
    
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
?>